# Copyright (c) 2026 Santiago Hofwimmer
"""
main_window.py – Top-level QMainWindow shell for the Qt GUI.

Owns the shared :class:`AppState`, the left control panel (datasheet / run /
history controls), and the central tab area. Lifecycle logic lives in the
controllers (:mod:`chipify.gui_qt.controllers`); per-tab views live in
:mod:`chipify.gui_qt.tabs`. The window exposes a small, stable surface
(``show_results``, ``set_running_ui``, ``refresh_history`` …) that the
controllers call back into.
"""
from __future__ import annotations

import logging
from pathlib import Path

from PySide6.QtCore import Qt, QTimer, QUrl
from PySide6.QtGui import QDesktopServices, QGuiApplication
from PySide6.QtWidgets import (
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QStatusBar,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from chipify import __version__, app_config, settings
from chipify import data_loader as _dl
from chipify.uikit.services import equation_service as _eq_svc
from chipify.uikit.state import AppState
from chipify.gui_qt import theme
from chipify.gui_qt.controllers.history_controller import HistoryController
from chipify.gui_qt.controllers.simulation_controller import SimulationController
from chipify.gui_qt.tabs.analytics_tab import AnalyticsTab
from chipify.gui_qt.tabs.editor_tab import DatasheetEditorTab
from chipify.gui_qt.tabs.histogram_tab import HistogramTab
from chipify.gui_qt.tabs.measurements_tab import MeasurementsTab
from chipify.gui_qt.tabs.transient_tab import TransientTab
from chipify.gui_qt.widgets.helpers import compact_combo, deferred

log = logging.getLogger("chipify.gui_qt.main_window")

_LEFT_PANEL_WIDTH = 320


class MainWindow(QMainWindow):
    """Application shell: left control panel + central tab widget + status bar."""

    NO_DATASHEETS = "No files found"

    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Chipify EDA Dashboard")
        # Preferred restored (un-maximized) size, clamped to the screen so it
        # never overflows a small display. app.py shows the window maximized;
        # this is the size it returns to when the user un-maximizes.
        self._set_initial_size(1300, 950)

        #: Single source of truth, shared with controllers and tab views.
        self.app_state = AppState()
        self.theme_name = theme.load_theme_name()

        self.sim_controller = SimulationController(self)
        self.history_controller = HistoryController(self)

        self._build_ui()
        self.app_state.status_changed.connect(self._on_status_changed)
        self.app_state.data_changed.connect(self.update_run_summary)
        self.app_state.on_data_chunk_added.connect(self.update_run_summary)

        # Populate selectors, then auto-load the last run once the loop is idle.
        self.refresh_datasheets()
        self.refresh_history()
        self.editor_tab.load_datasheet()
        self.set_status(f"Chipify {__version__} — ready.")
        QTimer.singleShot(0, self.history_controller.auto_load_latest)
        log.debug("MainWindow constructed (theme=%s).", self.theme_name)

    # ── Layout ────────────────────────────────────────────────────────────────

    def _set_initial_size(self, width: int, height: int) -> None:
        """Resize to (*width*, *height*) but never larger than the screen.

        Caps the requested size to ~95% of the available geometry (work area,
        i.e. excluding the taskbar) of the screen the window will appear on, so
        the restored window fits even on a small display.
        """
        screen = self.screen() or QGuiApplication.primaryScreen()
        if screen is not None:
            avail = screen.availableGeometry()
            width = min(width, int(avail.width() * 0.95))
            height = min(height, int(avail.height() * 0.95))
            log.info("Initial window size %dx%d (screen work area %dx%d).",
                     width, height, avail.width(), avail.height())
        else:
            log.warning("No screen available; using requested size %dx%d.",
                        width, height)
        self.resize(width, height)

    def _build_ui(self) -> None:
        central = QWidget(self)
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        root.addWidget(self._build_left_panel())

        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.editor_tab = DatasheetEditorTab(self)
        # The equations editor is embedded as the editor's third column; alias it
        # so show_results() can report derived columns back to it.
        self.equations_tab = self.editor_tab.equations_panel
        self.measurements_tab = MeasurementsTab(self.app_state)
        self.histogram_tab = HistogramTab(self.app_state, self.plot_theme)
        self.analytics_tab = AnalyticsTab(self.app_state, self.plot_theme)
        self.transient_tab = TransientTab(self.app_state, self.plot_theme)
        self.tabs.addTab(self.editor_tab, "Datasheet Editor")
        self.tabs.addTab(self.measurements_tab, "Measurements")
        self.tabs.addTab(self.histogram_tab, "Histogram")
        self.tabs.addTab(self.analytics_tab, "Analytics")
        self.tabs.addTab(self.transient_tab, "Transient")
        self._setup_plugin_tabs()
        root.addWidget(self.tabs, stretch=1)

        self.setCentralWidget(central)
        self.setStatusBar(QStatusBar(self))
        self._status_label = QLabel("")
        self.statusBar().addWidget(self._status_label)

    def _build_left_panel(self) -> QFrame:
        panel = QFrame()
        panel.setObjectName("LeftPanel")
        panel.setFixedWidth(_LEFT_PANEL_WIDTH)

        layout = QVBoxLayout(panel)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        title = QLabel("Chipify")
        title.setObjectName("Heading")
        layout.addWidget(title)
        subtitle = QLabel("Mismatch · sweeps · yield")
        subtitle.setObjectName("Muted")
        layout.addWidget(subtitle)

        # ── Datasheet selector ────────────────────────────────────────────────
        layout.addSpacing(6)
        layout.addWidget(self._section("DATASHEET"))
        ds_row = QHBoxLayout()
        ds_row.setSpacing(6)
        self.datasheet_combo = QComboBox()
        compact_combo(self.datasheet_combo, length=16)
        self.datasheet_combo.textActivated.connect(deferred(self._on_datasheet_changed))
        ds_row.addWidget(self.datasheet_combo, stretch=1)
        self.btn_refresh = QPushButton("↺")
        self.btn_refresh.setFixedWidth(36)
        self.btn_refresh.setToolTip("Rescan the datasheets folder")
        self.btn_refresh.clicked.connect(self.refresh_datasheets)
        ds_row.addWidget(self.btn_refresh)
        layout.addLayout(ds_row)

        # ── Run controls ──────────────────────────────────────────────────────
        layout.addSpacing(6)
        self.btn_start = QPushButton("Start Simulation")
        self.btn_start.setObjectName("Accent")
        self.btn_start.clicked.connect(self.sim_controller.start)
        layout.addWidget(self.btn_start)

        self.btn_stop = QPushButton("Stop Simulation")
        self.btn_stop.setObjectName("Danger")
        self.btn_stop.setEnabled(False)
        self.btn_stop.clicked.connect(self.sim_controller.stop)
        layout.addWidget(self.btn_stop)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        layout.addWidget(self.progress_bar)

        # ── Results summary (always visible) ──────────────────────────────────
        layout.addSpacing(12)
        layout.addWidget(self._section("RESULTS"))
        layout.addWidget(self._build_summary_card())

        # ── History ───────────────────────────────────────────────────────────
        layout.addSpacing(12)
        layout.addWidget(self._section("HISTORY"))
        hist_row = QHBoxLayout()
        hist_row.setSpacing(6)
        self.history_combo = QComboBox()
        compact_combo(self.history_combo, length=16)
        self.history_combo.textActivated.connect(deferred(self.history_controller.on_select))
        hist_row.addWidget(self.history_combo, stretch=1)
        self.btn_annotate = QPushButton("✎")
        self.btn_annotate.setFixedWidth(36)
        self.btn_annotate.setToolTip("Edit notes / tags for the selected run")
        self.btn_annotate.clicked.connect(self.annotate_run)
        hist_row.addWidget(self.btn_annotate)
        layout.addLayout(hist_row)

        # ── Actions ───────────────────────────────────────────────────────────
        layout.addSpacing(12)
        self.btn_pdf = QPushButton("Export PDF Report")
        self.btn_pdf.clicked.connect(self.export_pdf)
        layout.addWidget(self.btn_pdf)
        self.btn_open_folder = QPushButton("Open Output Folder")
        self.btn_open_folder.clicked.connect(self.open_output_folder)
        layout.addWidget(self.btn_open_folder)
        self.btn_multiplot = QPushButton("Multi-Plot Dashboard")
        self.btn_multiplot.clicked.connect(self.open_multiplot)
        layout.addWidget(self.btn_multiplot)
        self.btn_settings = QPushButton("Settings")
        self.btn_settings.clicked.connect(self.open_settings)
        layout.addWidget(self.btn_settings)

        layout.addStretch(1)
        return panel

    @staticmethod
    def _section(text: str) -> QLabel:
        lbl = QLabel(text)
        lbl.setObjectName("Section")
        return lbl

    def _build_summary_card(self) -> QFrame:
        """Always-visible run summary: duration, samples, valid, yield."""
        card = QFrame()
        card.setObjectName("Card")
        grid = QGridLayout(card)
        grid.setContentsMargins(12, 10, 12, 10)
        grid.setHorizontalSpacing(8)
        grid.setVerticalSpacing(4)

        self.sum_duration = QLabel("—")
        self.sum_samples = QLabel("—")
        self.sum_valid = QLabel("—")
        self.sum_yield = QLabel("—")
        rows = (
            ("Duration", self.sum_duration),
            ("Samples", self.sum_samples),
            ("Valid", self.sum_valid),
            ("Yield", self.sum_yield),
        )
        for r, (label, value) in enumerate(rows):
            name = QLabel(label)
            name.setObjectName("Stat")
            value.setObjectName("StatValue")
            value.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            grid.addWidget(name, r, 0)
            grid.addWidget(value, r, 1)
        grid.setColumnStretch(1, 1)
        return card

    def update_run_summary(self, **_kwargs) -> None:
        """Refresh the left-panel run summary from the active results."""
        df = self.app_state.active_df
        if df is None or len(df) == 0:
            for lbl in (self.sum_duration, self.sum_samples,
                        self.sum_valid, self.sum_yield):
                lbl.setText("—")
            self.sum_yield.setStyleSheet("")
            return
        s = _dl.result_summary(df)
        dur = self.app_state.last_sim_duration_sec
        self.sum_duration.setText(f"{dur:.1f} s" if dur else "—")
        self.sum_samples.setText(str(s.total))
        self.sum_valid.setText(str(s.valid))
        if "global_pass" in df.columns and s.total:
            yld = s.yield_pct
            self.sum_yield.setText(f"{yld:.1f} %")
            color = "#2ecc71" if yld >= 99.0 else ("#f1c40f" if yld >= 90.0 else "#e74c3c")
            self.sum_yield.setStyleSheet(f"color: {color};")
        else:
            self.sum_yield.setText("—")
            self.sum_yield.setStyleSheet("")

    # ── Plugin tabs ───────────────────────────────────────────────────────────

    def _setup_plugin_tabs(self) -> None:
        """Discover and host QtTabPlugins; warn about unsupported Tk ones."""
        from chipify.uikit.services.plugin_context import PluginContext
        from chipify.gui_qt.services.main_thread import MainThreadInvoker
        from chipify.plugin_loader import (
            get_qt_tab_plugins,
            warn_unsupported_tab_plugins,
        )

        #: container QWidget → (plugin instance, PluginContext)
        self._plugin_tabs: dict = {}
        self._invoker = MainThreadInvoker(self)
        warn_unsupported_tab_plugins()

        for cls in get_qt_tab_plugins():
            name = str(getattr(cls, "name", "") or "").strip()
            if not name:
                continue
            container = QWidget()
            ctx = PluginContext(
                self.app_state,
                get_yaml_path=lambda: self.current_yaml_path,
                tk_after=self._invoker.after,
                set_status=self.set_status,
                plugin_name=name,
            )
            try:
                plugin = cls()
                plugin.build(container, ctx)
            except Exception as exc:  # noqa: BLE001
                log.exception("Qt tab plugin %r failed to build.", name)
                layout = container.layout() or QVBoxLayout(container)
                layout.addWidget(QLabel(f"Plugin '{name}' failed to load:\n{exc}"))
                self.tabs.addTab(container, name)
                continue
            self.tabs.addTab(container, name)
            self._plugin_tabs[container] = (plugin, ctx)

        self.app_state.data_changed.connect(self._notify_plugins_data_changed)
        self.tabs.currentChanged.connect(self._notify_plugin_on_show)

    def _notify_plugins_data_changed(self, **_kwargs) -> None:
        for plugin, ctx in self._plugin_tabs.values():
            try:
                plugin.on_data_changed(ctx)
            except Exception:  # noqa: BLE001
                log.exception("Qt tab plugin on_data_changed failed.")

    def _notify_plugin_on_show(self, index: int) -> None:
        entry = self._plugin_tabs.get(self.tabs.widget(index))
        if entry is not None:
            plugin, ctx = entry
            try:
                plugin.on_show(ctx)
            except Exception:  # noqa: BLE001
                log.exception("Qt tab plugin on_show failed.")

    def closeEvent(self, event) -> None:  # noqa: N802 (Qt override)
        for plugin, _ctx in getattr(self, "_plugin_tabs", {}).values():
            try:
                plugin.on_close()
            except Exception:  # noqa: BLE001
                log.exception("Qt tab plugin on_close failed.")
        super().closeEvent(event)

    # ── Theme ─────────────────────────────────────────────────────────────────

    def plot_theme(self) -> dict:
        """Active matplotlib palette for the plot tabs."""
        return theme.plot_theme(self.theme_name)

    def _apply_appearance_now(self) -> None:
        """Apply the current theme + font size (palette, QSS, app font) and
        repaint the plots."""
        from PySide6.QtWidgets import QApplication
        font_size = int(app_config.load_config().get("font_size", 13))
        app = QApplication.instance()
        if app is not None:
            font = app.font()
            font.setPointSize(font_size)
            app.setFont(font)
            app.setPalette(theme.build_palette(self.theme_name))
            app.setStyleSheet(theme.build_qss(self.theme_name, font_size))
        # Re-emit so the plot tabs redraw with the new matplotlib palette.
        if self.app_state.current_df is not None:
            self.app_state.data_changed.emit(
                df=self.app_state.current_df,
                stim=self.app_state.current_stim,
                switch_tab=False,
            )

    def apply_theme(self, name: str) -> None:
        """Switch the live theme by name and restyle the app."""
        self.theme_name = name
        self._apply_appearance_now()

    def apply_appearance(self) -> None:
        """Re-read theme + font size from config and restyle the app."""
        self.theme_name = theme.load_theme_name()
        self._apply_appearance_now()

    # ── Actions ───────────────────────────────────────────────────────────────

    def open_settings(self) -> None:
        from chipify.gui_qt.widgets.settings_dialog import SettingsDialog
        SettingsDialog(self).exec()

    def open_multiplot(self) -> None:
        existing = getattr(self, "_multiplot", None)
        if existing is not None and existing.isVisible():
            existing.raise_()
            existing.activateWindow()
            return
        from chipify.gui_qt.multiplot_window import MultiPlotWindow
        self._multiplot = MultiPlotWindow(self.app_state, self.plot_theme)
        self._multiplot.show()

    def annotate_run(self) -> None:
        label = self.history_combo.currentText()
        if not label or label == "No runs found":
            return
        csv_path = _dl.resolve_csv_path(label, settings.OUT_DIR)
        if not csv_path:
            return
        from chipify.gui_qt.widgets.run_annotation_dialog import RunAnnotationDialog
        RunAnnotationDialog(self, label, csv_path).exec()
        self.refresh_history()

    def open_output_folder(self) -> None:
        Path(settings.OUT_DIR).mkdir(parents=True, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(settings.OUT_DIR)))

    def export_pdf(self) -> None:
        df = self.app_state.current_df
        stim = self.app_state.current_stim
        if df is None or stim is None:
            QMessageBox.warning(self, "Export PDF", "No simulation data to export.")
            return
        self.set_status("Generating PDF report…", "yellow")
        try:
            from chipify import pdf_export
            path = pdf_export.generate_pdf_report(
                df, stim, self.current_yaml_path,
                Path(settings.OUT_DIR) / "reports",
                sim_duration_sec=self.app_state.last_sim_duration_sec,
            )
        except Exception as exc:  # noqa: BLE001
            self.set_status("PDF export failed", "#e74c3c")
            QMessageBox.critical(self, "Export PDF", f"Failed to generate PDF:\n{exc}")
            return
        self.set_status("PDF saved to out/reports/", "#2ecc71")
        QMessageBox.information(self, "Export PDF", f"Report saved as:\n{Path(path).name}")

    # ── Selectors ─────────────────────────────────────────────────────────────

    @property
    def current_yaml_path(self) -> str | None:
        """Absolute path of the selected datasheet, or None."""
        name = self.datasheet_combo.currentText()
        if not name or name == self.NO_DATASHEETS:
            return None
        return str(Path(settings.IN_DIR) / name)

    def refresh_datasheets(self) -> None:
        """Rescan the input folder for ``*.yaml`` / ``*.yml`` datasheets."""
        in_dir = Path(settings.IN_DIR)
        files = sorted(
            p.name
            for ext in ("*.yaml", "*.yml")
            for p in in_dir.glob(ext)
        )
        self.datasheet_combo.blockSignals(True)
        self.datasheet_combo.clear()
        self.datasheet_combo.addItems(files if files else [self.NO_DATASHEETS])
        self.datasheet_combo.blockSignals(False)

    def refresh_history(self, select_latest: bool = False) -> None:
        """Repopulate the history combo for the current datasheet."""
        self.history_controller.refresh(select_latest=select_latest)

    def _on_datasheet_changed(self, _text: str) -> None:
        self.refresh_history()
        self.editor_tab.load_datasheet()

    def set_active_datasheet(self, name: str) -> None:
        """Rescan datasheets, select *name*, and load it into the editor."""
        self.refresh_datasheets()
        if name:
            self.datasheet_combo.setCurrentText(name)
        self.refresh_history()
        self.editor_tab.load_datasheet()

    # ── Results surface (called by controllers) ───────────────────────────────

    def show_results(self, df, stim, switch_tab: bool = False) -> None:
        """Install a result DataFrame into AppState and notify the views.

        Mirrors the legacy ``update_ui_results``: normalise ``sim_error``,
        (re)compute ``global_pass``, apply saved custom (scalar) equations so
        derived columns are available to every tab, publish to AppState, and
        emit ``data_changed``.
        """
        df = _dl.compute_global_pass(_dl.normalise_sim_error(df))
        equations = _eq_svc.scalar_equations(stim)
        df, derived, _logs = _eq_svc.apply_scalar_equations(df, equations)
        self.app_state.derived_cols = derived

        self.app_state.partial_df = None
        self.app_state.simulation_active = False
        self.app_state.current_df = df
        self.app_state.current_stim = stim
        self.app_state.data_changed.emit(df=df, stim=stim, switch_tab=switch_tab)
        self.equations_tab.report_derived(derived)
        if switch_tab:
            self.tabs.setCurrentWidget(self.measurements_tab)

    def reapply_equations(self) -> None:
        """Re-run the current results through ``show_results`` to refresh
        derived columns after the equation list changes.

        The stim is re-parsed from the active datasheet first — equations live
        in the datasheet YAML, so the in-memory stim would otherwise keep
        serving the pre-edit equation list."""
        df = self.app_state.current_df
        if df is None:
            return
        stim = self.app_state.current_stim
        if self.current_yaml_path:
            try:
                from chipify import util
                stim = util.Stimuli(self.current_yaml_path)
            except Exception as exc:  # noqa: BLE001 — keep the old stim on parse errors
                log.warning("reapply_equations: could not re-parse datasheet: %s", exc)
        self.show_results(df, stim, switch_tab=False)

    def show_error(self, message: str) -> None:
        """Surface a simulation error on the measurements tab."""
        self.measurements_tab.show_error(message)
        self.tabs.setCurrentWidget(self.measurements_tab)

    # ── Run-state UI ──────────────────────────────────────────────────────────

    def set_running_ui(self, running: bool) -> None:
        """Toggle controls between idle and running states."""
        self.btn_start.setEnabled(not running)
        self.btn_stop.setEnabled(running)
        self.btn_refresh.setEnabled(not running)
        self.datasheet_combo.setEnabled(not running)
        self.history_combo.setEnabled(not running)
        if not running:
            self.progress_bar.setValue(0)

    # ── Status bar ────────────────────────────────────────────────────────────

    def set_status(self, text: str, color: str | None = None) -> None:
        """Update the status-bar message (optionally with a colour override)."""
        self._status_label.setText(text)
        self._status_label.setStyleSheet(f"color: {color};" if color else "")

    def _on_status_changed(self, text: str = "", color: str = "") -> None:
        """Slot for ``AppState.status_changed`` (kwargs: text, color)."""
        self.set_status(text, color or None)
