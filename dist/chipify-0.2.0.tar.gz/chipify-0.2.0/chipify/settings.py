# Copyright (c) 2026 Santiago Hofwimmer
# settings.py
"""Project path configuration.

Folder locations are read from ``settings.json`` in the project root (the
current working directory). Any path key that is missing or blank falls back
to the default folder structure under the project root. Paths are resolved
once at import, so edits to ``settings.json`` take effect on the next launch.

Configurable keys (in ``settings.json``):
    in_dir    – input datasheets    (default: ``datasheets/``)
    out_dir   – simulation output   (default: ``out/``)
    work_dir  – model files staged to the simulator scratch dir
                (*.lib/*.mod/*.inc; default: ``work/``)
    tb_dir    – testbench files     (default: ``tb/``)

Relative paths are resolved against the project root; absolute paths are used
as-is. ``FAST_TMP`` (volatile scratch, tmpfs-backed on typical Linux/Docker
setups) is not configurable; it is namespaced per project so concurrent
chipify instances on different projects do not share staged files or the
abort flag.

All path constants exported here are :class:`pathlib.Path` objects.
"""
import hashlib
import json
import logging
import tempfile
from pathlib import Path
from typing import Any

log = logging.getLogger("chipify.settings")

# The directory chipify was launched from — anchor for relative paths.
PROJECT_ROOT = Path.cwd()

# settings.json lives in the project root (the same file app_config reads/writes).
_CONFIG_PATH = PROJECT_ROOT / "settings.json"

# Default folder layout, relative to PROJECT_ROOT. work_dir was "tmp" before
# 0.3 — misleading, since it never held temporary data (FAST_TMP does); it is
# the input folder for model files that get staged next to the netlists.
_DEFAULT_DIRS = {
    "in_dir": "datasheets",
    "out_dir": "out",
    "work_dir": "work",
    "tb_dir": "tb",
}


def _load_path_overrides() -> dict[str, Any]:
    """Read folder-path overrides from settings.json (``{}`` if absent/unreadable).

    Kept self-contained (no ``app_config`` import) because ``app_config`` imports
    this module — reading the JSON inline avoids a circular import.
    """
    try:
        with open(_CONFIG_PATH, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _resolve_dir(key: str, overrides: dict[str, Any]) -> Path:
    """Return the absolute path for *key*, honouring a settings.json override.

    Uses the override when it is a non-empty string (resolved against
    ``PROJECT_ROOT`` if relative); otherwise falls back to the default folder.
    The resulting directory is created. If a configured custom path cannot be
    created, a warning is logged and the default folder is used instead.
    """
    default_abs = PROJECT_ROOT / _DEFAULT_DIRS[key]

    raw = overrides.get(key)
    if isinstance(raw, str) and raw.strip():
        custom = Path(raw.strip())
        if not custom.is_absolute():
            custom = PROJECT_ROOT / custom
        try:
            custom.mkdir(parents=True, exist_ok=True)
            return custom
        except OSError as exc:
            log.warning(
                "Could not create configured %s=%r (%s); using default %s",
                key, raw, exc, default_abs,
            )

    default_abs.mkdir(parents=True, exist_ok=True)
    return default_abs


_overrides = _load_path_overrides()

IN_DIR = _resolve_dir("in_dir", _overrides)
OUT_DIR = _resolve_dir("out_dir", _overrides)
WORK_DIR = _resolve_dir("work_dir", _overrides)
TB_DIR = _resolve_dir("tb_dir", _overrides)

# Volatile scratch space; not configurable. One directory per project (hash of
# PROJECT_ROOT) under the system temp dir, so that:
#   - the abort flag of one chipify instance cannot stop another project's run,
#   - staged .lib/.mod/.inc files from different projects never collide,
#   - Windows gets a real temp location instead of a literal "\tmp" folder.
# On typical Linux/Docker setups the system temp dir is tmpfs (RAM-backed).
_project_tag = hashlib.md5(str(PROJECT_ROOT).encode("utf-8")).hexdigest()[:10]
FAST_TMP = Path(tempfile.gettempdir()) / f"chipify_{_project_tag}"
FAST_TMP.mkdir(parents=True, exist_ok=True)
